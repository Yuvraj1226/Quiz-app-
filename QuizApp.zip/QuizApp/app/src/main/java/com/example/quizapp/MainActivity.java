package com.example.quizapp;

import android.annotation.SuppressLint;
import android.content.Intent;
import android.os.Bundle;
import android.os.CountDownTimer;
import android.widget.*;
import androidx.appcompat.app.AppCompatActivity;
import java.util.ArrayList;
import java.util.Arrays;

public class MainActivity extends AppCompatActivity {

    TextView questionText, timerText, scoreText;
    RadioGroup optionsGroup;
    Button prevButton, nextButton, submitButton, homeButton;
    ArrayList<Question> questions;
    int currentQuestionIndex = 0;
    int[] selectedAnswers;
    int score = 0;
    CountDownTimer countDownTimer;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        questionText = findViewById(R.id.questionText);
        timerText = findViewById(R.id.timerText);
        scoreText = findViewById(R.id.scoreText);
        optionsGroup = findViewById(R.id.optionsGroup);
        prevButton = findViewById(R.id.prevButton);
        nextButton = findViewById(R.id.nextButton);
        submitButton = findViewById(R.id.submitButton);
        homeButton = findViewById(R.id.homeButton);

        homeButton.setOnClickListener(v -> {
            startActivity(new Intent(MainActivity.this, HomeActivity.class));
            finish();
        });

        loadQuestions();
        selectedAnswers = new int[questions.size()];
        Arrays.fill(selectedAnswers, -1);
        displayQuestion();

        nextButton.setOnClickListener(v -> {
            saveSelectedOption();
            if (currentQuestionIndex < questions.size() - 1) {
                currentQuestionIndex++;
                displayQuestion();
            }
        });

        prevButton.setOnClickListener(v -> {
            saveSelectedOption();
            if (currentQuestionIndex > 0) {
                currentQuestionIndex--;
                displayQuestion();
            }
        });

        submitButton.setOnClickListener(v -> {
            saveSelectedOption();
            if (currentQuestionIndex < questions.size() - 1) {
                currentQuestionIndex++;
                displayQuestion();
            } else {
                showScore();
            }
        });
    }

    void startTimer() {
        if (countDownTimer != null) countDownTimer.cancel();

        countDownTimer = new CountDownTimer(30000, 1000) {
            @SuppressLint("SetTextI18n")
            public void onTick(long millisUntilFinished) {
                timerText.setText((millisUntilFinished / 1000) + "s");
            }

            public void onFinish() {
                Toast.makeText(MainActivity.this, "Time's up! Moving to next question.", Toast.LENGTH_SHORT).show();
                if (currentQuestionIndex < questions.size() - 1) {
                    currentQuestionIndex++;
                    displayQuestion();
                } else {
                    showScore();
                }
            }
        }.start();
    }

    void loadQuestions() {
        questions = new ArrayList<>();
        questions.add(new Question("What is the capital of India?", new String[]{"Mumbai", "New Delhi", "Kolkata", "Chennai"}, 1));
        questions.add(new Question("Who is known as the Father of the Nation in India?", new String[]{"Nehru", "Patel", "Gandhi", " Ambedkar "}, 2));
        questions.add(new Question("Which is the largest planet?", new String[]{"Mars", "Earth", "Jupiter", "Venus"}, 2));
        questions.add(new Question("How many colors are there in a rainbow?", new String[]{"5", "6", "7", "8"}, 2));
        questions.add(new Question("Which animal is known as the Ship of the Desert?", new String[]{"Elephant", "Camel", "Horse", "Donkey"}, 1));
        questions.add(new Question("Who wrote the Indian national anthem?", new String[]{"Gandhi", "Nehru", "Tagore", "Tilak"}, 2));
        questions.add(new Question("Which organ purifies blood in the human body?", new String[]{"Heart", "Lungs", "Kidney", "Liver"}, 2));
        questions.add(new Question("Which is the national bird of India?", new String[]{"Sparrow", "Peacock", "Crow", "Pigeon"}, 1));
        questions.add(new Question("Which gas do plants absorb?", new String[]{"Oxygen", "Carbon Dioxide", "Hydrogen", "Nitrogen"}, 1));
        questions.add(new Question("What is the currency of Japan?", new String[]{"Won", "Yuan", "Dollar","Yen"},3));// Add more questions as needed
    }

    @SuppressLint("SetTextI18n")
    void displayQuestion() {
        Question q = questions.get(currentQuestionIndex);
        questionText.setText("Q" + (currentQuestionIndex + 1) + ": " + q.getQuestionText());
        optionsGroup.removeAllViews();

        for (int i = 0; i < q.getOptions().length; i++) {
            RadioButton rb = new RadioButton(this);
            rb.setText(q.getOptions()[i]);
            rb.setId(i);
            optionsGroup.addView(rb);
            if (selectedAnswers[currentQuestionIndex] == i) rb.setChecked(true);
        }

        scoreText.setText("Score: " + score);
        prevButton.setEnabled(currentQuestionIndex != 0);
        nextButton.setEnabled(currentQuestionIndex < questions.size() - 1);
        startTimer();
    }

    void saveSelectedOption() {
        int selectedId = optionsGroup.getCheckedRadioButtonId();
        if (selectedAnswers[currentQuestionIndex] == -1 && selectedId == questions.get(currentQuestionIndex).getCorrectAnswerIndex()) {
            score++;
        }
        selectedAnswers[currentQuestionIndex] = selectedId;
    }

    void showScore() {
        if (countDownTimer != null) countDownTimer.cancel();

        Intent intent = new Intent(MainActivity.this, ResultActivity.class);
        intent.putExtra("score", score);
        intent.putExtra("total", questions.size());
        startActivity(intent);
        finish();
    }
}